/**************************************************************
 * 
 * CacheTable.h
 * 
 * Header file for Hash Table data structure that maps 
 * string keys to cachelines that contain the relevant 
 * data/memory being stored.
 * 
 * Amy Bui (abui02)
 * 9/10/2022
 **************************************************************/
#include "CacheLine.h"
#include "Response.h"

#ifndef _CACHETABLE_INCLUDED_
#define _CACHETABLE_INCLUDED_
typedef struct CacheTable *CacheTable;

/**
 * CacheTable_new
 * Initializes a new CacheTable in memory with size number of buckets.
 */
extern CacheTable CacheTable_new(long int size);

/**
 * CacheTable_free
 * Deallocates the memory of the given CacheTable.
 */
extern void CacheTable_free(CacheTable *table);

/**
 * CacheTable_size
 * Returns the number of items the CacheTable currently is holding, 
 * i.e. number of cache lines / files stored.
 */
extern long int CacheTable_size(CacheTable table);

/**
 * CacheTable_insert
 * Inserts a cache line with the data corresponded to the file with the
 * named key. Returns the name of an evicted file, if any.
 */
extern void CacheTable_insert(CacheTable table, char *key, char *value, 
                              unsigned long size, unsigned int maxAge);

/**
 * CacheTable_get
 * Returns the value mapped to by the given key. Value returned as a CacheLine.
 */
extern CacheLine CacheTable_get(CacheTable table, char *key);

/* Debug printing for the hash table. */
extern void CacheTable_print(CacheTable table);


#undef CacheTable
#endif