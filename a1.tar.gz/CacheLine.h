/**************************************************************
 * 
 * CacheLine.h
 * 
 * Header file for Cache Line 
 * 
 * Amy Bui (abui02)
 * 9/10/2022
 **************************************************************/
#include "Node.h"
#include <time.h>
// #include "Response.h"
#ifndef _CACHELINE_INCLUDED_
#define _CACHELINE_INCLUDED_
typedef struct CacheLine *CacheLine;

/**
 * CacheLine_new
 * Returns a pointer to memory allocated for a CacheLine struct 
 * that contains a file name called key, the integer for max age 
 * of some content called timeToLive. 
 */
extern CacheLine CacheLine_new(char *key, char *value, unsigned long size,
                               unsigned int timeToLive, Node *node);

/**
 * CacheLine_free
 * Deallocates memory pointed to by cacheline.
 */
// extern void CacheLine_free(CacheLine *cacheline);
extern void CacheLine_free(void **line);

/**
 * CacheLine_filename
 * Returns the name of the file thats stored in the CacheLine
 */
extern char *CacheLine_key(CacheLine cacheline);

/**
 * CacheLine_memory
 * Returns the data/memory stored in the CacheLine
 */
extern char *CacheLine_memory(CacheLine cacheline);

/**
 * CacheLine_memorySize
 * Returns the size of the data/memory stored in the CacheLine
 */
extern unsigned long CacheLine_memorySize(CacheLine cacheline);


/**
 * CacheLine_isStale
 * Returns 0 if the given CacheLine is stale. o.w. it isn't stale. 
 */
extern unsigned int CacheLine_isStale(CacheLine cacheline);

/**
 * CacheLine_isValid
 * Returns 0 if the given CacheLine is not valid. o.w. it is stale. 
 */
// extern unsigned int CacheLine_wasTouched(CacheLine cacheline);

/**
 * CacheLine_size
 * Returns size of file content the CacheLine stores.
 */
// extern unsigned int CacheLine_size(CacheLine cacheline);

/**
 * CacheLine_maxAge
 * Returns maxage of file content the CacheLine stores.
 */
extern unsigned int CacheLine_maxAge(CacheLine cacheline);

/**
 * CacheLine_insertionTime
 * Returns the time in sec that cache line was created.
 */
extern time_t CacheLine_insertionTime(CacheLine cacheline);

/** 
 * Cachline_fifoMember
 * returns the fifo member field in the cache line to the specified node.
 */
extern Node *CacheLine_fifoMember(CacheLine line);

/** 
 * Cachline_setFifo
 * resets the fifo member field in the cache line to the specified node.
 */
extern void CacheLine_setFifo(CacheLine line, Node *node);

/**
 * CacheLine_updateMemory
 * Rewrites the file content to the specified cache line and updates the 
 * max age to timeToLive. Returns a pointer to the node containing 
 * the filename of the cacheline. 
 */
extern Node *CacheLine_updateMemory(CacheLine line, char *value, 
                                    unsigned long size, 
                                    unsigned int timeToLive);

extern unsigned int CacheLine_reportCurrentAge(CacheLine line);

/**
 * CacheLine_print
 * Prints the data of cache line to standard output for debugging. 
 */
extern void CacheLine_print(CacheLine cacheline);

#undef CacheLine
#endif