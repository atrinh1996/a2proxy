/**************************************************************
 * 
 * CacheTable.c
 * 
 * Implementation file for Hash Table data structure for cache assignment.
 * 
 * Amy Bui (abui02)
 * 9/10/2022
 **************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "CacheTable.h"
#include "LinkedList.h"
#include "CacheLine.h"
#include "Node.h"

struct CacheTable {
    long int capacity;
    long int count; 
    /* string linked lists to keep track of eviction priority */
    LinkedList lru; /* the tracking nodes will point to the same key str 
                       contained in the table's cachelines. */
    LinkedList *buckets;  /* array of CacheLine Node link lists pointers */
};

/********************** "private" method declarations **********************/
void freeString(void **str);
unsigned int CacheTable_isFull(CacheTable table);
Node *CacheTable_find(CacheTable table, char *key);
LinkedList CacheTable_getBucket(CacheTable table, char *key);
void printCacheLineLL(LinkedList list, Node *node, void *line, void *cl);
void printStringLL(LinkedList list, Node *node, void *str, void *cl);
void searchForStales(LinkedList list, Node **staleLine, time_t *staleAge);
void CacheTable_replacementPolicy(CacheTable table);
void CacheTable_replacementPolicyLRU(CacheTable table);
/****************************************************************************/

/* The djb2 hash function (1991) in C for hashing string keys. */
unsigned long hash(unsigned char *str) 
{
    unsigned long hash = 5381;
    int c;
    while ((c = *str++)) 
        hash = ((hash << 5) + hash) + c; 

    return hash;
}

/* Calculates the hash (bucket) value for the given string key. Returns 
   pointer to the appropriate bucket in the hash table. */
LinkedList CacheTable_getBucket(CacheTable table, char *key)
{
    unsigned long hashIndex = hash((unsigned char *)key) % table->capacity;
    return table->buckets[hashIndex];
}

/**
 * CacheTable_new
 * Purpose: Allocate memory for a hash table with size number of buckets.
 * Parameter: size for the number of buckets the table should have.
 * Return: pointer to the new table. 
 */
CacheTable CacheTable_new(long int size)
{
    CacheTable table = malloc(sizeof(struct CacheTable));

    table->capacity = size;
    table->count = 0;
    table->lru = LinkedList_new();

    table->buckets = malloc(sizeof(LinkedList) * size);
    long int i = 0;
    for (i = 0; i < size; i++) {
        table->buckets[i] = LinkedList_new();
    }

    return table;
}


/**
 * CacheTable_free
 * Purpose: Deallocates the memory of the given CacheTable.
 * Parameter: The table we are removing.
 * Return: none.
 */
void CacheTable_free(CacheTable *table)
{
    /* Freeing linked list depends on the type of data each stored. */
    LinkedList_free(&(*table)->lru, freeString);

    long int size = (*table)->capacity;
    long int i = 0;
    for (i = 0; i < size; i++) {
        LinkedList_free(&(*table)->buckets[i], CacheLine_free);
    }
    /* free the array, then the table */
    free((*table)->buckets);
    free(*table);
}

/**
 * CacheTable_size
 * Purpose: gets the number of items in the hash table.
 * Parameter: the table we are looking ar. 
 * Return: the count of items in table.
 */
long int CacheTable_size(CacheTable table) { return table->count; }


/**
 * CacheTable_insert
 * Purpose: insert a new item into the hash table. (PUT command)
 * Parameter: the table we are inserting into, the string key to hash
 *            to the appropriate bucket, and the max age of the file to 
 *            be stored.
 * Return: name of evicted file if any
 * Side Effect: Inserts new cache line into the table; if line was previously
 *              inserted, this updates current cache line and makes it 
 *              as though it was newly inserted. 
 *              Increases count of items in the table.
 */
void CacheTable_insert(CacheTable table, char *key, char *value,
                       unsigned long size, unsigned int maxAge)
{
    Node *item = CacheTable_find(table, key); /* cache line with target item */
    if (item == NULL) { 
        /* 
         * Insertion procedure for NEW cache line (PUT new memory):
         */

        /* 1) deal with full cache. */
        if (CacheTable_isFull(table)) 
            CacheTable_replacementPolicy(table);

        /* 2) create the fifo queue string node for new cache line. */
        Node *fifoMember = LinkedList_pushBack(table->lru, key);

        /* 3) create the cacheline to go into the table. */
        CacheLine line = CacheLine_new(key, value, size, maxAge, fifoMember);

        /* 4) find bucket to hash the value to. */
        LinkedList bucket = CacheTable_getBucket(table, key);

        /* 5) put cacheline into its bucket. */
        LinkedList_pushBack(bucket, line);

        /* 6) increment table count to include new item. */
        table->count++;

    } else { 
        /* 
         * Insertion procedure for existing cache line (PUT old file):
         */

        /* 1) update age and file contents on cache line. */
        CacheLine line = (CacheLine) Node_data(item);

        /* 2) find its lru node position */
        Node *fifoMember = CacheLine_updateMemory(line, value, size, maxAge);

        /* 3) update the key's poistion in the lru queue */
        LinkedList_remove(table->lru, fifoMember, freeString);
        char *id = CacheLine_key(line);
        Node *newMember = LinkedList_pushBack(table->lru, id);

        /* 4) update the fifo member of the cacheline. */
        CacheLine_setFifo(line, newMember);
    }
}

/**
 * CacheTable_find
 * Purpose: get a value from the table
 * Parameter: the key that maps to the value we are getting, and the table we 
 *            are getting from. 
 * Return: the Node value mapped to by the key as a CacheLine in it's node.
 * Note: An item does not appear twice in the cachetable
 */
Node *CacheTable_find(CacheTable table, char *key) 
{
    /* Get the bucket table item mapped to key WOULD be in. */
    LinkedList bucket = CacheTable_getBucket(table, key);
    Node *target = NULL;

    /* Do nothing if item is not in the hash table / bucket is empty */
    if (LinkedList_isEmpty(bucket)) return target;

    /* Find the right cache line in the chain, and return the node it belongs */
    Node *curr = NULL;
    for (curr = LinkedList_front(bucket); 
         curr != NULL; curr = Node_next(curr))
    {
        CacheLine data = (CacheLine) Node_data(curr);
        char *id = CacheLine_key(data);
        if (strcmp(key, id) == 0) {
            target = curr;
        }
    }
    return target;
}

/**
 * CacheTable_get
 * Purpose: get a value from the table
 * Parameter: the key that maps to the value we are getting, and the table we 
 *            are getting from. 
 * Return: the value mapped to by the key as a CacheLine.
 * Note: Cacheline returned may or may not be stale. It is job of user/client 
 *       to detect staleness and refetch stale items and reinsert 
 *       them into cache.
 */
CacheLine CacheTable_get(CacheTable table, char *key) 
{
    Node *target = CacheTable_find(table, key);
    if (target == NULL) return NULL; /* not in cache table*/

    CacheLine result = (CacheLine) Node_data(target);

    /* After a GET command, move the eviction priority for file to 
       end of fifo queue of those that have been recently used */
    Node *fifoMember = CacheLine_fifoMember(result);
    /////
    char *id = CacheLine_key(result);

    LinkedList_remove(table->lru, fifoMember, freeString);
    Node *newMember = LinkedList_pushBack(table->lru, id);
    CacheLine_setFifo(result, newMember);

    /* Responsibility of client (Cache) to use the returned CacheLine,
       i.e. read/touch the memory. */
    return result;
}

/**
 * CacheTable_print
 * Debug printing for the hash table.
 */
void CacheTable_print(CacheTable table)
{
    long int size = table->capacity;
    long int i = 0;
    printf("=========================================\n");
    for (i = 0; i < size; i++) {
        printf("BUCKET[%ld]: ", i);
        LinkedList_map(table->buckets[i], printCacheLineLL, NULL);
        printf("\n");
    }
    printf("\nLRU[]: ");
    LinkedList_map(table->lru, printStringLL, NULL);
    printf("\n");
    printf("=========================================\n\n");
}

/***************************************************************************
 ***************************************************************************
 ***************************************************************************/

/* contrived function to be used when deallocating a string linked list, 
   made with a generic linked list; "frees" non-heap strings. */
void freeString(void **str) {
    // char *myStr = (char *) *str;
    // free(myStr);
    (void) str;
}

/* Reports if current table is at capacity. */
unsigned int CacheTable_isFull(CacheTable table)
{
    return (table->count == table->capacity) ? 1 : 0;
}

/* Debug printing for the cache line items in a chaining hash table. */
void printCacheLineLL(LinkedList list, Node *node, void *line, void *cl)
{
    (void) cl;
    (void) list;
    (void) node;
    CacheLine cacheline = line;
    CacheLine_print(cacheline);
    printf(" --> ");
}

/* Debug printing for the cache line items in a chaining hash table. */
void printStringLL(LinkedList list, Node *node, void *str, void *cl)
{
    (void) cl;
    (void) list;
    (void) node;
    char *word = (char *)str;
    printf("%s", word);
    printf(" --> ");
}


/* iterate through each cacheline in the list, and mark it stale if it 
   is stale. Save a pointer to the stalest node and its insertion time. */
void searchForStales(LinkedList list, Node **staleLine, time_t *staleAge)
{
    Node *curr = NULL;
    for (curr = LinkedList_front(list);
         curr != NULL; curr = Node_next(curr))
    {
        CacheLine line = (CacheLine) Node_data(curr);
        if (CacheLine_isStale(line)) {
            time_t currAge = CacheLine_insertionTime(line); /* seconds */
            if (currAge < *staleAge) { // is older than current stale 
                *staleAge = currAge;
                *staleLine = curr;
            }
        }
    }
}

/* Method for replacement policy of the cache hash table. Lookes  first to 
   evict a stale line; when there are none, will evict the least recently
   used */
void CacheTable_replacementPolicy(CacheTable table)
{
    /* Find a stale CacheLine */
    struct timespec now;
    clock_gettime(CLOCK_MONOTONIC, &now);
    time_t ageHolder = now.tv_sec;
    Node *staleLine = NULL;
    long int size = table->capacity;
    long int i= 0;
    for (i = 0; i < size; i++) {
        LinkedList bucket = table->buckets[i];
        searchForStales(bucket, &staleLine, &ageHolder);
    }
    

    char *key = NULL;
    if (staleLine != NULL) {
        /* 
         * evict a stale line: 
         */
        /* 1) Determine which list/buckey the key for stale line is. */
        CacheLine line = (CacheLine) Node_data(staleLine);
        key = CacheLine_key(line);
        Node *fifoMember = CacheLine_fifoMember(line);
        LinkedList bucket = CacheTable_getBucket(table, key);

        /* 2) Remove stale cacheline from hash table. */
        LinkedList_remove(bucket, staleLine, CacheLine_free);

        /* 3) Remove filename node from list. */
        LinkedList_remove(table->lru, fifoMember, freeString);
        printf("here (x)\n\n");
    } else {
        /* When there are no stale lines, remove least recently used */
        CacheTable_replacementPolicyLRU(table);
    }
    table->count--;
}

/* Method for least recently used replacement policy. */
void CacheTable_replacementPolicyLRU(CacheTable table)
{
    /* Remove from the nevertouched cachelines first; else 
       look in the lru of those lines that had GET applied. */
    LinkedList list = table->lru;
    if (LinkedList_isEmpty(list)) return;

    /* get the LRU item's name node; remove from LRU tracker. */
    Node *leastRecentlyUsed = LinkedList_front(list);
    char *name = Node_data(leastRecentlyUsed);

    /* remove LRU's cache line from the table */
    LinkedList bucket = CacheTable_getBucket(table, name);

    LinkedList_popFront(list, freeString);

    Node *target = LinkedList_front(bucket);
    Node *curr = NULL;
    for (curr = target; curr != NULL; curr = Node_next(curr))
    {
        CacheLine data = (CacheLine) Node_data(curr);
        char *key = CacheLine_key(data);
        if (strcmp(key, name) == 0) {
        // if (name == key) {
            target = curr;
            break;
        }
    }
    LinkedList_remove(bucket, target, CacheLine_free);
}
