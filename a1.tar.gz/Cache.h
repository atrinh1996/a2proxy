/**************************************************************
 * 
 * Cache.h
 * 
 * Header file for cache represenation
 * * Only things going in cache is raw data (key-value) and 
 *   going out is CacheLines.
 * 
 * Amy Bui (abui02)
 * 9/27/2022
 **************************************************************/
#include "CacheLine.h"
#ifndef _CACHE_INCLUDED_
#define _CACHE_INCLUDED_
typedef struct Cache *Cache;


extern Cache Cache_new(long int capacity);
extern void Cache_free(Cache *cache);

/**
 * Cache_put
 * Stores content given by the file named key in the cache, 
 * and gives it the max age in seconds of maxAgeSec
 */
extern void Cache_put(Cache cache, char *key, char *value, 
                      unsigned long size, unsigned int sec);

/**
 * Cache_get
 * Retrieves content given by the file named key in the cache and 
 * writes content to a new file named key_output, followed by the 
 * file extension if any. 
 */
extern CacheLine Cache_get(Cache cache, char *key);

extern void Cache_print(Cache cache);

#undef Cache
#endif