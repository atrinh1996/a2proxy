/**************************************************************
 * 
 * LinkedList.h
 * 
 * Header file for LinkedList, generic linked list data structure. 
 * 
 * Amy Bui (abui02)
 * 9/10/2022
 **************************************************************/
#include "Node.h"
#ifndef _LINKEDLIST_INCLUDED_
#define _LINKEDLIST_INCLUDED_
typedef struct LinkedList *LinkedList;

/**
 * LinkedList_new
 * returns a pointer to a new, empty linked list. 
 */
extern LinkedList LinkedList_new();

/**
 * LinkedList_free
 * Deallocates the memory pointed to by list. 
 */
extern void LinkedList_free(LinkedList *list,
                            void applyFree(void **dataMember));

/**
 * LinkedList_isEmpty
 * Returns 0 if the linked list is not empty. o.w. it is empty.
 */
extern unsigned int LinkedList_isEmpty(LinkedList list);

/**
 * LinkedList_size
 * Returns the number of items in the list. 
 */
extern unsigned int LinkedList_size(LinkedList list);

/**
 * LinkedList_readNode
 * Returns the data contianed in the specified node of the linked list.
 */
// extern void *LinkedList_readNode(Node *node);

/**
 * LinkedList_front
 * Returns the first node of Linked List
 */
extern Node *LinkedList_front(LinkedList list);

/**
 * LinkedList_popFront
 * Removes first item of the list, returns what that item was.
 */
extern void LinkedList_popFront(LinkedList list,
                                void applyFree(void **dataMember));

/**
 * LinkedList_pushBack
 * Pushes a new string to end of the list. 
 */
extern Node *LinkedList_pushBack(LinkedList list, void *data);

/**
 * LinkedList_remove
 * Removes the node pointed to in the LinkedList
 */
extern void LinkedList_remove(LinkedList list, Node *node, 
                              void applyFree(void **dataMember));


/**
 * LinkedList_map
 * Mapping function that applies the second argument to each element of the LL.
 */
extern void LinkedList_map(LinkedList list, 
                           void apply(LinkedList list, Node *node, 
                                      void *elem, void *cl), 
                           void *cl);


#undef LinkedList
#endif