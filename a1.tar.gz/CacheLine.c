/**************************************************************
 * 
 * CacheLine.c
 * 
 * Implementation file for Cache Line, a type of data node with 
 * prev and next pointers.
 * 
 * Amy Bui (abui02)
 * 9/10/2022
 **************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "CacheLine.h"
// #include "FileContent.h"
#include "Response.h"

struct CacheLine {
    char *key; 
    unsigned int maxAge; // seconds
    // unsigned int isValid; // 0 for false, true o.w. AKA isNotStale.
    unsigned int isStale; // 0 for false, true o.w. AKA stale line.

    // remove?
    // unsigned int touched; // 0 for not touched, true for having been gotted. 

    // clock_t insertionTime;
    // clock_t accessTime;

    struct timespec insertionTime;
    
    // point to where fifo member is, to update queue during eviction. 
    Node *fifo;

    // "memory block"/content "being stored in cache"
    // FileContent data; 
    Response data;
};

/**
 * CacheLine_new
 * Purpose: Allocate memory for a cache line to contain data of a file, 
 *          name of file, and its max age. 
 * Parameter: the name of the file called key, and the max age 
 *            given by timeToLive.
 * Return: pointer to a CacheLine struct that contains data about the file.
 */
CacheLine CacheLine_new(char *key, char *value, unsigned long size,
                        unsigned int timeToLive, Node *node) 
{
    CacheLine line = malloc(sizeof(struct CacheLine));

    // int keylen = strlen(key);
    // line->key = malloc(keylen);
    // memcpy(line->key, key, keylen);
    line->key = key;

    line->maxAge = timeToLive;

    line->isStale = 0;
    // line->touched = 0;

    // line->insertionTime = clock();
    // line->accessTime = line->insertionTime;
    clock_gettime(CLOCK_MONOTONIC, &(line->insertionTime));

    line->fifo = node;

    // line->data = FileContent_new(key);
    line->data = Response_new(size, value);

    return line;
}

/**
 * CacheLine_free
 * Purpose: Deallocates the memory pointed to by cacheline.
 * Parameter: Pointer to the CacheLine to deallocate.
 * Returns: nothing. 
 */
// hint: struct CacheLine * == Cacheline
//       struct CacheLine ** == Cacheline *
//       CacheLine == void *
//       CacheLine * == void **
void CacheLine_free(void **line) 
// void CacheLine_free(CacheLine *cacheline)
{
    CacheLine *cacheline = (CacheLine *) line; 
    // printf("here (4)\n\n");
    free((*cacheline)->key);
    // printf("here (5)\n\n");
    Response_free(&(*cacheline)->data);
    // printf("here (6)\n\n");
    free(*cacheline);
    // printf("here (7)\n\n");
}

/**
 * CacheLine_key
 * Returns the name of the file thats stored in the CacheLine
 */
char *CacheLine_key(CacheLine cacheline) { return cacheline->key; }

/**
 * CacheLine_maxAge
 * Returns maxage of file content the CacheLine stores.
 */
unsigned int CacheLine_maxAge(CacheLine cacheline) { return cacheline->maxAge; }

/**
 * CacheLine_memory
 * Purpose: Returns the data/memory stored in the CacheLine.
 * Parameter: The CacheLine whose memory we are getting. 
 * Returns: the memory/file content/data represented as a char array. 
 * Side Effect: records when during the time of the program 
 *              this memory was requested/accessed by assigning 
 *              a new value to the CacheLine's accessTime member.
 */
char *CacheLine_memory(CacheLine cacheline)
{
    return Response_get(cacheline->data);
}

/**
 * CacheLine_memorySize
 * Purpose: Returns the size of the data/memory stored in the CacheLine (bytes)
 * Parameter: The CacheLine whose memory size we are getting. 
 * Returns: size in bytes of the memory / content.
 */
unsigned long CacheLine_memorySize(CacheLine cacheline)
{
    return Response_size(cacheline->data);
}


/**
 * Cachline_fifoMember
 * Purpose: returns the fifo member field in the cache line 
 * Parameter: The cache line we are looking at.
 * Return: pointer to the node pointer member of CacheLine.
 */
Node *CacheLine_fifoMember(CacheLine line) { return line->fifo; }

/**
 * Cacheline_setFifo
 * Purpose: assign a new node to the fifo field member of the CacheLine.
 * Parameter: The cache line we are updating, and the node to set the 
 *            the data field to.
 * Return: none.
 */
void CacheLine_setFifo(CacheLine line, Node *node) { line->fifo = node; } 


/**
 * CacheLine_insertionTime
 * Purpose: Returns the time in clock cycle that cache line was created.
 * Parameter: The CacheLine whose memory we are getting. 
 * Returns: the insertion time of the line. 
 */
time_t CacheLine_insertionTime(CacheLine cacheline) 
{ 
    time_t sec = cacheline->insertionTime.tv_sec;
    return sec;
    // return cacheline->insertionTime; 
}


/**
 * CacheLine_updateMemory
 * Purpose: rewrites the file content to the current cacheline
 * Parameter: the cacheline we are looking at, and a new max age to set.
 * Return: return the location of fifo member so the hashtable can 
 *         remove it from the queue and put it at the end.
 * Side Effect: This resets the insertion time of the line, makes it
 *              "valid", and flips its touch status to 0.
 */
Node *CacheLine_updateMemory(CacheLine line, char *value, 
                             unsigned long size, unsigned int timeToLive)
{
    line->maxAge = timeToLive;
    line->isStale = 0;
    // line->touched = 0; // don't change GET'd status if we are re-PUTting
    // line->insertionTime = clock();
    clock_gettime(CLOCK_MONOTONIC, &(line->insertionTime));
    // line->accessTime = line->insertionTime;

    Response_free(&(line->data));
    line->data = Response_new(size, value);

    return line->fifo;
}

/**
 * CacheLine_isStale
 * Purpose: determine if current CacheLine is stale or not. 
 * Parameter: The CacheLine we are checking. 
 * Return: 0 if the given CacheLine is not stale. o.w. it is stale. 
 * Side Effect: Changes the isStale member of the CacheLine if
 *              the line became stale.
 */
unsigned int CacheLine_isStale(CacheLine cacheline)
{
    if (cacheline->isStale) return 1;   // stale, not valid 
    
    // not previously set to invalid / stale; check times.
    struct timespec currentTime; 
    clock_gettime(CLOCK_MONOTONIC, &currentTime);

    unsigned int time_since_insertion =  /* seconds */
        (unsigned int) (currentTime.tv_sec - cacheline->insertionTime.tv_sec);
    
    if (time_since_insertion > cacheline->maxAge) {
        cacheline->isStale = 1;
        return 1;
    }
    return 0;
}

/**
 * CacheLine_isStale
 * Purpose: reports age of cache line in seconds since insertion
 * Parameter: The CacheLine we are checking. 
 * Return: the age in seconds. 
 */
unsigned int CacheLine_reportCurrentAge(CacheLine line)
{
    struct timespec currentTime; 
    clock_gettime(CLOCK_MONOTONIC, &currentTime);

    unsigned int time_since_insertion =  /* seconds */
        (unsigned int) (currentTime.tv_sec - line->insertionTime.tv_sec);

    return (unsigned int) time_since_insertion;
}




/**
 * CacheLine_print
 * Purpose: Prints the cache line information contained in given CacheLine.
 * Parameter: a CacheLine called cacheline.
 * Returns: nothing. 
 */
void CacheLine_print(CacheLine cacheline)
{
    printf("%s", cacheline->key);
}