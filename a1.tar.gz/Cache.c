/**************************************************************
 * 
 * Cache.c
 * 
 * Implementation file for cache 
 * 
 * Amy Bui (abui02)
 * 9/10/2022
 **************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include "Cache.h"
#include "CacheTable.h"
// #include "CacheLine.h"

struct Cache {
    CacheTable cacheTable;
};

// char *getOutputFilename(char *orig);

/**
 * Cache_new
 * Purpose: Allocates memory for a cache as designed by the above struct.
 * Parameter: an integer representing the desired size of the cache. 
 * Return: a pointer to a Cache object. 
 */
Cache Cache_new(long int size) 
{
    Cache cache = malloc(sizeof(struct Cache));
    cache->cacheTable = CacheTable_new(size);
    return cache;
}

/**
 * Cache_free
 * Purpose: Deallocates memory of the given cache
 * Parameter: a pointer to the cache to deallocate.
 * Return: none.
 */
void Cache_free(Cache *cache)
{
    CacheTable_free(&(*cache)->cacheTable);
    free(*cache);
}


/**
 * Cache_put
 * Purose: Inserts new memory into the cache.
 * Parameter: the cache in which to insert into, the key in which to map
 *            the data to, its max age as an int, and the data value itself
 *            coming in through a void pointer.
 * Return: none.
 */
void Cache_put(Cache cache, char *key, char *value, 
               unsigned long size, unsigned int sec)
{
    CacheTable_insert(cache->cacheTable, key, value, size, sec);
}

/**
 * Cache_get
 * Purose: Executes the GET command on a cache to fetch the data mapped to 
 *         by the given key.
 * Parameter: the cache in which we are looking, and the name of the data
 *            we are querying for.
 * Return: The cacheline that was requested, NULL if it was not in the cache.
 */
CacheLine Cache_get(Cache cache, char *key) 
{
    CacheLine line = CacheTable_get(cache->cacheTable, key);
    return line;
}

void Cache_print(Cache cache)
{
    CacheTable_print(cache->cacheTable);
}
