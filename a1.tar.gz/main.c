/**************************************************************
 * main.c
 * 
 * main program driver.
 * 
 * Amy Bui (abui02)
 * 9/29/2022
 **************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include "proxy.h"

int main(int argc, char *argv[])
{
    if (argc != 2) {
        fprintf(stderr, "Usage: ./a.out <port number>\n");
        exit(1);
    }

    unsigned short port = (unsigned short) strtoul(argv[1], NULL, 10);

    Proxy proxy = Proxy_new(port);
    Proxy_run(proxy);
    Proxy_free(&proxy);

    return 0;
}