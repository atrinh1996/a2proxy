/**************************************************************
 * 
 * StrNode.c
 * 
 * Implementation file for Node, which holds a 
 * general data and a previous and next pointer to other nodes.
 * 
 * Amy Bui (abui02)
 * 9/10/2022
 **************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include "Node.h"


Node *Node_new(void *d, Node *p, Node *n) 
{
    Node *node = malloc(sizeof(struct Node));
    node->data = d;
    node->prev = p;
    node->next = n;
    return node;
}

void  Node_free(Node *node, void applyFree(void **dataMember)) 
{ 
    applyFree(&(node->data));
    free(node); 
}

Node *Node_prev(Node *node) { return node->prev; }
Node *Node_next(Node *node) { return node->next; }
void *Node_data(Node *node) { return node->data; }

void Node_setPrev(Node *node, Node *p) { node->prev = p; }
void Node_setNext(Node *node, Node *n) { node->next = n; }
void Node_setData(Node *node, void *d) { node->data = d; }