/**************************************************************
 * 
 * Node.h
 * 
 * Header file for Node, a generic node
 * 
 * Amy Bui (abui02)
 * 9/10/2022
 **************************************************************/
#ifndef _NODE_INCLUDED_
#define _NODE_INCLUDED_
typedef struct Node Node;

struct Node {
    Node *prev;
    Node *next;
    void *data;
};

/* Returns a pointer to a Node containing data d, and points back to node p 
   points forward to node n. */
extern Node *Node_new(void *d, Node *p, Node *n);

/* Deallocates memory of current node, and uses the applyFree function 
   argument to deallocate the node's data member. */
extern void  Node_free(Node *node, void applyFree(void **dataMember));

/* Returns a pointer to the node pointed to by the prev pointer of node. */
extern Node *Node_prev(Node *node);

/* Returns a pointer to the node pointed to by the next pointer of node. */
extern Node *Node_next(Node *node);

/* Returns a pointer to the specified node's data member. */
extern void *Node_data(Node *node);

/* Sets the current node's prev pointer to p. */
extern void Node_setPrev(Node *node, Node *p);

/* Sets the current node's next pointer to n. */
extern void Node_setNext(Node *node, Node *n);

/* Sets the current node's data member to d. */
extern void Node_setData(Node *node, void *d);


#undef Node
#endif