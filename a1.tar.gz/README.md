# CS 112 - Networks and Protocols
## Homework A1: HTTP, Proxy Caching, and Socket Programming
Amy Bui (abui02)

Fall 2022

## PURPOSE
Simulate a Proxy that has Shared Proxy Cache. Uses modified implementation of my Cache module.

## COMPILE & RUN
Compile with:
> `make` 

Run with:
> `./a.out <port number>`
- `port number` is the port that the proxy will listen on for client requests.

Suggested ways to test with http:
```
    curl -x http://localhost:<proxy's port> <http website>

    curl -x http://localhost:<proxy's port> http://localhost:<local server's port>
```

## FILES
- `README.md`: this file 
### A1 (new) FILES
- `main.c`: main program file. processes command input file. 
- `proxy.h/proxy.c`: implementation of proxy with shared proxy cache.
- `parser.h/parser.c`: implementation of http response parser.
- `Response.h`/`Response.c`: implementation of http response structure.
### A0 FILES
- `Cache.h`/`Cache.c`: implementation of simulated cache.
- `CacheTable.h`/`CacheTable.c`: hash table data structure specifically for cache simulating.
- `LinkedList.h`/`LinkedList.c`: implementation of generalized linked list.
- `Node.h`/`Node.c`: implementation of generalized node with double pointers.
- `CacheLine.h`/`CacheLine.c`: implementation of cache line encapsulation.


## SPECIFICATION

### My assigned ports for testing (*on halligan servers):
9010, 9011, 9012, 9013, 9014


### I. Simple Proxy 
- The proxy will listen for **client connection request** on the port that was passed as the command line argument.
    - The proxy will handle one client at a time. 
    - Serve the client request, disconnect, wait for another connection request. 
    - Assume **non-persistant** connection
- Upon **connection request**
    - client establishes connection with proxy on the port
    - proxy waits for **HTTP request**, then does one of: 
        - A. if requested content not in proxy's cache: 
            - **forwards request to server**
            - Cache the server's response (See Part II. Caching)
            - serve server's response to client 
            - close connection to server and client. 
        - B. if requested content is in cache:
            - If not stale, server content from cache. 
            - If stale, do (A)
- Only handle **GET** requests.
- Assume port 80 if no port number is specified in HTTP request (for automated testing of submission).
- Proxy runs indefinitely. Keep waiting for more connection requests.

Proxy pseudo process:
```
loop(forever):
    /** SERVER BEHAVIOR **/
    1. listen on port <NUM>;
    2. Receive client connection request;
    3. Establish connection with client;
    4. GET client HTTP request;
    5. Check if in Proxy's Cache:
        5a. Present:
            6. Check if Stale:
                6a. is not Stale: get CONTENT from cache
                6b. is Stale: goto 5b

        /** CLIENT BEHAVIOR **/
        5b. Not Present (or stale):
            6. establish connection with server;
            7. forward the request to server; 
            ?. forward response to client. 
            8. process the server's response: cache/update the CONTENT
            9. Close connection to server

    10. Serve CONTENT to client.
    11. Close connection to current client
```


### II. Caching 
The Proxy's cache can be used to service multiple clients, and serve one of its cache resource to other clients (*Shared Proxy Cache*). This is to free up the network and bandwidth for clients requesting new data from servers.

- `Cache-Control: max-age=<N>` 
    - When your proxy gets this in the server response header, the proxy should just be able to handle the `max-age` directive. `N` is the number of seconds that the data remains fresh (not stale).
    - When no `Cache-Control` is specified, your proxy should still cache the content and it is fresh for 1 hour (**3600 seconds**)
- Proxy should modify and report current `Age` of the content it is serving to the client (submission testing).
    - `Age` should be put in the head **ONLY WHEN DATA IS SERVED FROM PROXY CACHE**. 
    - `Age` can be put anywhere in response header, **AFTER THE FIRST LINE**
- Cache stores the responses of the **10 most recently** GET requested URLs
- Responses:
    - 1. GET data, in the cache and fresh: return cached data from proxy cache, NO forwarding request to server 
    - 2. GET data, in the cache but is stale: refetch data from server, forward response to client, and update it in the proxy cache.
    - 3. GET data, not in cache, cache not full: forward request to server, cache response, and forward response to client. 
    - 4. GET data, not in cache, cache is full (10 max cap): eviction priority:
        - a. evict a single stale item 
        - b. if none stale, remove the least recently accessed one. 
            - *here, everything is considered accessed at least once since they are in the proxy's cache.*
            - *should modify cache to remove the "neverTouched" resources*
- Name of cached item is < 100 chars
- Size of cached item is <= 10 MB
- Different ports on the same domain are **different**, and should be cached separately.
    - `www.example.com:8001` != `www.example.com:8000`
    - if port is not specified, assume port 80 for the HTTP request
- ignore concerns for query parameters for now
- **Cache the servers response in its entirety. Cache the head and the content for this assignment**
- Note changes to A0 cache implementation:
    - remove Nevers list(?)
    - modify GET method to not attempt to refetch stale items.



## ACKNOWLEDGEMENTS


## REFERENCES
[MDN WebDocs: Age header](https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Age)


## ARCHITECTURE

```
+------+   +------------+      +----------+ 
| Node |-->| LinkedList |      | Response |
+------+   +------------+      +----------+ 
    |       |                       |       
    V       V                       V       
    +------------+          +-----------+  
    | CacheTable | <------- | CacheLine |   
    +------------+ __     __+-----------+   
                     |   |                  
                     V   V                  
                    +-------+      +-----------+        +--------+ 
                    | Cache | ---> |   PROXY   | <----- | PARSER |
                    +-------+      +-----------+        +--------+
                                       | 
                                       V
                                    +------+ 
                                    | MAIN |
                                    +------+ 
```


## Data Structure
See discussion and justifcation of A0 Cache Data Structure. 

Changes:
- key's are malloc'd strings, and the same memory is used as 
    cache line key AND key for string linked list in cache. 
- value stored in Cache is Response structure. 

## Parsing
Most parsing of HTTP message is done with the following assumptions:
- HTTP message format matches the standard
    - header fields all end in CRLF
    - there is a CRLF between end of Header and start of Body 
- Content-Length is always provided in Responses
- Headers may be case-insensitive 

Parsing strategy:
- End of header/start of body can be found by searching for "\r\n\r\n" using strstr()
- Do case-insensitive string comparison in order to find target header fields. 
- When getting a range of subbytes from a message, allocate +1 more bytes of what to read in and place a \0; however, retain actual length of bytes of the target. 
- when appending ranges of bytes, similarly, allocated +1 more than the desired size, place a \0 there, and memcpy() using positions of start, relative to start, and using actual length of the byte ranges you are concatenating. You may run into more complicated memory issues if you use snprintf() or strtok_r() if you are not familiar with using them or do not properly deallocate any temporary buffers. 