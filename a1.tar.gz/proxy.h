/**************************************************************
 * proxy.h
 * 
 * Header file for implemenation of a proxy with shared 
 * proxy cache.
 * 
 * Amy Bui (abui02)
 * 9/20/2022
 **************************************************************/
#ifndef _PROXY_INCLUDED_
#define _PROXY_INCLUDED_
typedef struct Proxy *Proxy;

extern Proxy Proxy_new(unsigned short portNumber);

extern void Proxy_free(Proxy *proxy);

extern void Proxy_run(Proxy proxy);

extern void Proxy_print(Proxy proxy);

#endif