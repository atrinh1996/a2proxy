/**************************************************************
 * parser.h
 * 
 * Header file for various http message parsing module
 * 
 * Amy Bui (abui02)
 * 9/29/2022
 **************************************************************/
#ifndef _PARSER_INCLUDED_
#define _PARSER_INCLUDED_


/* returns heap allocated copy of the header of the message. */
extern char *parse_headerRaw(char *message);
extern char *parse_headerRawTrim(char *message);
extern char *parse_headerLower(char *message);


/* returns heap allocated copy of the body of the message. */
extern char *parse_bodyRaw(char *message, int size);

/* returns body length */
extern unsigned long calculate_bodySize(char *message, int size);

/* returns specified header field values */
extern unsigned int parse_maxAge(char *header);
extern long parse_contentLength(char *header);
extern void parse_host(char *header, char **key,
                       char **hostname, unsigned short *port);

/* creates a heal allocated string of Age header field */
extern char *make_ageField(unsigned int age);

/* returns true if buffer has a whole http header in it */
extern unsigned int hasHeader(char *buffer);



/* removes space char from string starting at str address, and until size. */
extern char *removeSpaces(char *str, int size);

/* returns heap allocated string copied from start up to but no incl end.
   copy ends in null char. */
extern char *getBufferFrom(char *start, char *end);

/* returns heap allocated string copied from start up to but no incl end.
   copy ends in null char. All chars are lower case'd. */
extern char *bufferToLower(char *buf, char *end);


/* DEBUG PRINTING */
/* prints string of size size in the following format: 
 * <#>::<char>::<char-as-int>\n */
extern void parse_printcharsvertical(char *str, int size);

/* prints up to but not including the byte at [size],
   as we don't expect a \0 */
void parse_printBufVertical(char *buf, int size);

/* prints buffer's bytes as is up to but not including [size] */
void parse_printBufRaw(char *buf, int size);

#endif