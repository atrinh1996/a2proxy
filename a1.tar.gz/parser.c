/**************************************************************
 * parser.c
 * 
 * implementation file for various http message parsing module
 * 
 * Amy Bui (abui02)
 * 9/20/2022
 **************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "parser.h"

#define HDRFLAG "\r\n\r\n"
#define HDR_LN_END "\r\n"
#define CONTLEN "content-length:"
#define CONTLEN_SIZE 15
#define HOST "host: " /* "host:" appears in localhost:9010 in first line */
#define HOST_SIZE 6
#define CACHECONTROL "cache-control:"
#define CACHECONTROL_SIZE 14
#define MAXAGE "max-age="
#define MAXAGE_SIZE 8
#define DEFAULTAGE 3600 /* seconds */


/* Given an HTTP response message, return just the header parsed out as a 
   new heap allocated string with \0 at end; inlcudes last \r\n\r\n */
char *parse_headerRaw(char *message)
{
    char *flag = strstr(message, HDRFLAG);
    if (flag == NULL) return NULL;

    char *header = getBufferFrom(message, flag + 4); /* malloc'd */
    return header;
}

/* Given an HTTP response message, return just the header parsed out as a 
   new heap allocated string with \0 at end; doesn't include last \r\n */
char *parse_headerRawTrim(char *message)
{
    char *flag = strstr(message, HDRFLAG);
    if (flag == NULL) return NULL;

    char *header = getBufferFrom(message, flag + 2); /* malloc'd */
    return header;
}

/* Given an HTTP response message, return just the header parsed out as a 
   new heap allocated string with \0 at end, all letters lowercase.
   header goes until the last \r\n\r\n */
char *parse_headerLower(char *message)
{
    char *flag = strstr(message, HDRFLAG);
    if (flag == NULL) return NULL;

    char *header = bufferToLower(message, flag + 4); /* malloc'd */
    return header;
}

/* Given an HTTP response message, return just the body parsed out, no
   leading CR-LF. size is the full size of message, and includes size of 
   header, if any. */
char *parse_bodyRaw(char *message, int size)
{
    char *flag = strstr(message, HDRFLAG);
    if (flag == NULL) return message;

    char *bodyStart = flag + 4;
    char *bodyEnd = message + size;

    char *body = getBufferFrom(bodyStart, bodyEnd); /* malloc'd */
    return body;
}

/* Returns size of the body bytes in http response message. message
   is expected to be formatted as http response with header\r\n\r\nbody */
unsigned long calculate_bodySize(char *message, int size)
{
    char *flag = strstr(message, HDRFLAG);
    if (flag == NULL) return size;

    char *bodyStart = flag + 4;
    char *bodyEnd = message + size;

    return bodyEnd - bodyStart;
}


/* returns content-length from given header; header must have all lowercase; 
   -1 if it did not exist */
long parse_contentLength(char *header)
{
    char *startContLenField = strstr(header, CONTLEN);
    if (startContLenField == NULL) return -1;

    char *endContLenField = strstr(startContLenField, HDR_LN_END);

    char *value = getBufferFrom(startContLenField + CONTLEN_SIZE, 
                                endContLenField); /* malloc'd */

    value = removeSpaces(value, strlen(value));
 
    unsigned long contentLength = strtoul(value, NULL, 10);

    free(value);
    return contentLength;
}

/* parses out the max age if any from a lowercase'd header. Default age
   if field isn't present. */
unsigned int parse_maxAge(char *header)
{
    char *startCCField = strstr(header, CACHECONTROL);
    if (startCCField == NULL) return DEFAULTAGE;

    char *endCCField = strstr(startCCField, HDR_LN_END);

    char *value = getBufferFrom(startCCField + CACHECONTROL_SIZE, 
                                endCCField + 2); /* malloc'd */
    value = removeSpaces(value, strlen(value));

    char *startMAField = strstr(value, MAXAGE);
    if (startMAField == NULL) return DEFAULTAGE;

    char *endMAField = strstr(startMAField, HDR_LN_END);

    char *age = getBufferFrom(startMAField + MAXAGE_SIZE, 
                                endMAField); /* malloc'd */
    age = removeSpaces(age, strlen(age));
    unsigned int maxAge = strtoul(age, NULL, 10);

    free(value);
    free(age);
    return maxAge;
}

/* sets key (resource string), hostname, and port numbers from 
   given header (lowercase'd) */
void parse_host(char *header, char **key, 
                char **hostname, unsigned short *port)
{
    // char *endResourceLine = strstr(header, HDR_LN_END);
    char *firstSpaceResourceLine = strstr(header, " ");
    char *secondSpaceResourceLine = strstr(firstSpaceResourceLine + 1, " ");
    char *resource = getBufferFrom(firstSpaceResourceLine + 1, 
                                   secondSpaceResourceLine); /* malloc'd */
    int keysize = strlen(resource);
    *key = malloc(keysize + 1); /* malloc'd */
    (*key)[keysize] = '\0';
    memcpy(*key, resource, keysize);
    /*****/

    char *startHostField = strstr(header, HOST);
    char *endHostField = strstr(startHostField, HDR_LN_END);

    char *value = getBufferFrom(startHostField + HOST_SIZE, 
                                endHostField); /* malloc'd */
    
    value = removeSpaces(value, strlen(value));
    int size = strlen(value);

    char *colon = strstr(value, ":");
    if (colon != NULL) {
        *port = (unsigned short) strtoul(colon + 1, NULL, 10);
        // printf("Port (parser): %u\n", *port);

        size = colon - value;
        *hostname = malloc(size + 1);  /* malloc'd */
        (*hostname)[size] = '\0';

        memcpy(*hostname, value, size); 
        // printf("Hostname (parser): %s\n", *hostname);
    } else {
        *hostname = malloc(size + 1);  /* malloc'd */
        (*hostname)[size] = '\0';
        memcpy(*hostname, value, size); 
        // printf("Hostname (parser): %s\n", *hostname);
    }

    free(resource);
    free(value);
}

/* returns the string for "Age: <age>\r\n" */
char *make_ageField(unsigned int age)
{
    char *field = calloc(18, sizeof(char));
    int size = snprintf(field, 18, "Age: %u\r\n", age);
    // printf("Age field: \"%s\"\t\tSize: %d\t\t\"size\": %d\n\n", field, strlen(field), size);
    field = realloc(field, size + 1);
    // printf("Age field: \"%s\"\t\tSize: %d\t\t\"size\": %d\n\n", field, strlen(field), size);
    return field;
}

/* returns a malloc'd string copy of buffer where letters are all lowercase 
   up to but not including end. */
char *bufferToLower(char *buf, char *end) 
{
    int size = end - buf;
    char *copy = malloc(size + 1);
    copy[size] = '\0';

    char *i;
    int j = 0;
    for (i = buf, j = 0; i != end; i++, j++) {
        if (isalpha(*i)) {
            copy[j] = tolower(*i);
        } else {
            copy[j] = *i;
        }
    }

    return copy;
}

/* returns a malloc'd string copy of buffer 
   up to but not including end. */
char *getBufferFrom(char *start, char *end)
{
    int size = end - start;
    char *copy = malloc(size + 1);
    copy[size] = '\0';

    memcpy(copy, start, size);
    return copy;
}

/* looks for "\r\n\r\n" to flag that buffer contains an http header */
unsigned int hasHeader(char *buffer)
{
    char *flag = strstr(buffer, HDRFLAG);
    if (flag == NULL) return 0;
    else return 1;

    // if (flag == NULL) {
    //     fprintf(stderr, "no header\n\n");
    //     return 0;
    // }
    // else {
    //     fprintf(stderr, "has header\n\n");
    //     return 1;
    // }
}


/**
 * Removes space characters in a given string, and returns the modified string.
 */
char *removeSpaces(char *str, int size)
{
    unsigned int strIdx = 0;
    int i = 0;
    for (i = 0; i < size; i++) {
        if (str[i] != ' ') {
            str[strIdx] = str[i];
            strIdx++;
        }
    }
    str[strIdx] = '\0';
    return str;
}

/* prints string of size size in the following format: 
 * <#>::<char>::<char-as-int>\n
 * up to and including [size]
 */
void parse_printcharsvertical(char *str, int size)
{
    int i = 0; 
    for (i = 0; i <= size; i++) {
        fprintf(stdout, "%d::", i);
        if (str[i] == '\r')
            fprintf(stdout, "<CR>");
        else if (str[i] == '\n')
            fprintf(stdout, "<LF>");
        else if (str[i] == '\0')
            fprintf(stdout, "<\\0>");
        else if (str[i] == ' ')
            fprintf(stdout, "<SPACE>");
        else 
            putc(str[i], stdout);

        fprintf(stdout, "::%d\n", str[i]);
    }
}

/* prints string of size size in the following format: 
 * <#>::<char>::<char-as-int>\n
 * up to but not including [size]
 */
void parse_printBufVertical(char *buf, int size)
{
    int i = 0; 
    for (i = 0; i < size; i++) {
        fprintf(stdout, "%d::", i);
        if (buf[i] == '\r')
            fprintf(stdout, "<CR>");
        else if (buf[i] == '\n')
            fprintf(stdout, "<LF>");
        else if (buf[i] == '\0')
            fprintf(stdout, "<\\0>");
        else if (buf[i] == ' ')
            fprintf(stdout, "<SPACE>");
        else 
            putc(buf[i], stdout);

        fprintf(stdout, "::%d\n", buf[i]);
    }
}

/* prints buffer's bytes as is up to but not including [size] */
void parse_printBufRaw(char *buf, int size)
{
    int i = 0; 
    for (i = 0; i < size; i++) {
        putc(buf[i], stdout);
    }
}