/**************************************************************
 * 
 * LinkedList.c
 * 
 * Implementation file for LinkedList, generic linked list data structure. 
 * 
 * Amy Bui (abui02)
 * 9/10/2022
 **************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include "LinkedList.h"

struct LinkedList {
    unsigned int count;
    Node *front;
    Node *back;
};


/**
 * LinkedList_new
 * Purpose: Allocates memory for a new linked list
 * Parameter: none.
 * Returns: a pointer to a new, empty linked list. 
 */
LinkedList LinkedList_new()
{
    struct LinkedList *list = malloc(sizeof(struct LinkedList));
    list->count = 0;
    list->front = NULL;
    list->back = NULL;
    return list;
}

/**
 * LinkedList_free
 * Purpose: Deallocates the memory pointed to by list. 
 * Parameter: a linked list to deallocate, and a function that will deallocate
 *            memory specified by list member elements. 
 * Return: none.
 */
void LinkedList_free(LinkedList *list, void applyFree(void **dataMember))
{
    Node *f = (*list)->front;
    Node *next = NULL;
    while (f != NULL) {
        next = Node_next(f);
        Node_free(f, applyFree);
        f = next; 
    }

    (*list)->front = NULL;
    (*list)->back = NULL;
    free(*list);
}

/**
 * LinkedList_isEmpty
 * Purpose: tells whether or not the linked list is empty.
 * Parameter: the linked list we are checking
 * Return: 0 if the linked list is not empty. o.w. it is empty.
 */
unsigned int LinkedList_isEmpty(LinkedList list)
{
    return (list->front == NULL) ? 1 : 0; 
}

/**
 * LinkedList_size
 * Purpose: report the number of items in the list. 
 * Parameter: the list we are checking.
 * Return: size of the list. 
 */
unsigned int LinkedList_size(LinkedList list) { return list->count; }

/**
 * LinkedList_readNode
 * Purpose: gets the data contained by the node
 * Parameter: the node we want to read.
 * Return: the data contianed in the specified node
 */
// void *LinkedList_readNode(Node *node) { return Node_data(node); }

/**
 * LinkedList_front
 * Purpose: gets the front of the list.
 * Parameter: the list we are looking at.
 * Returns: the first node of Linked List; NULL if it is empty
 */
Node *LinkedList_front(LinkedList list)
{
    if (list->front != NULL) return list->front;
    else return NULL;
}


/**
 * LinkedList_popFront
 * Purpose: Removes first item of the list
 * Parameter: the list we are looking at, and a function that deallocates 
 *            the type of data being removed.
 * Return: none.
 */
void LinkedList_popFront(LinkedList list, void applyFree(void **dataMember))
{
    Node *next = Node_next(list->front);

    Node_free(list->front, applyFree);
    list->front = next;

    if (next == NULL)  list->back = NULL; 
    else Node_setPrev(next, NULL);

    list->count--;
}

/**
 * LinkedList_pushBack
 * Purpose: Pushes a new item to end of the list. 
 * Parameter: the list we are adding to, and the element which we are adding
 *            called data.
 * Return: a pointer to the newly added node.
 * 
 */
Node *LinkedList_pushBack(LinkedList list, void *data)
{
    Node *new = Node_new(data, list->back, NULL);
    if (list->back == NULL) {
        list->front = new;
        list->back = new;
    } else {
        Node_setNext(list->back, new);
        list->back = new;
    }
    list->count++;
    return new;
}

/**
 * LinkedList_remove
 * Purpose: Removes the node pointed to in the LinkedList
 * Parameter: the list we are looking at, the specified node in the list 
 *            to be removed, and a function that specifies how to deallicate
 *            the node's data member.
 * Return: none.
 */
void LinkedList_remove(LinkedList list, Node *node, 
                        void applyFree(void **dataMember))
{
    Node *nprev = Node_prev(node);
    Node *nnext = Node_next(node);

    if (nprev != NULL) Node_setNext(nprev, nnext);
    else list->front = nnext;

    if (nnext != NULL) Node_setPrev(nnext, nprev);
    else list->back = nprev;

    Node_free(node, applyFree);
    list->count--;
}

/**
 * LinkedList_map
 * Purpose: perform an method on each element of the list.
 * Parameter: the list to map over, the function to apply, 
 *            and a closure argument.
 * Return: none.
 */
extern void LinkedList_map(LinkedList list, 
                           void apply(LinkedList list, Node *node, 
                                      void *elem, void *cl), 
                           void *cl)
{
    Node *curr = NULL;
    for (curr = list->front; curr != NULL; curr = Node_next(curr)) {
        void *value = Node_data(curr);
        apply(list, curr, value, cl);
    }
}