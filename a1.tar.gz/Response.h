/**************************************************************
 * Response.h
 * 
 * Header file for implemenation of a response structure.
 * 
 * Amy Bui (abui02)
 * 9/20/2022
 **************************************************************/
#ifndef _RESPONSE_INCLUDED_
#define _RESPONSE_INCLUDED_
typedef struct Response *Response;

extern Response         Response_new(unsigned long size, char *message);
extern void             Response_free(Response *response);
extern char *           Response_get(Response response);
extern unsigned long    Response_size(Response response);
extern void             Response_print(Response response);

#endif