/**************************************************************
 * proxy.c
 * 
 * Implementation file for implemenation of a proxy with shared 
 * proxy cache.
 * 
 * Amy Bui (abui02)
 * 9/20/2022
 **************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h> // close()
#include "proxy.h"
#include "parser.h"
#include "Cache.h"
#include "CacheLine.h"

#define CACHE_CAPACITY 1
#define BACKLOG 1
#define BUFSIZE 1024

struct Proxy {
    unsigned short port;
    Cache cache;
};


/****************************************************************
 * Private proxy methods
 */
void Proxy_server(Proxy proxy);

char *Proxy_client(Proxy Proxy, char *request, size_t requestSize,
                          char *hostname, unsigned short port, 
                          unsigned long *size);

void Proxy_read(int fd, char **buffer, int *bytesRead);
/****************************************************************/


/**
 * Proxy_new
 * Purpose: Allocates memory for a proxy as designed by the above struct.
 * Parameter: an integer representing port number the proxy listens on.
 * Return: a pointer to a proxy object. 
 */
Proxy Proxy_new(unsigned short portNumber)
{
    Proxy proxy = malloc(sizeof(struct Proxy));
    proxy->port = portNumber;
    proxy->cache = Cache_new(CACHE_CAPACITY);
    return proxy;
}

/**
 * Proxy_free
 * Purpose: Deallocates memory of the given proxy
 * Parameter: a pointer to the proxy to deallocate.
 * Return: none.
 */
void Proxy_free(Proxy *proxy)
{
    Cache_free(&(*proxy)->cache);
    free(*proxy);
}

/**
 * Proxy_run
 * Purpose: runs the proxy to listen for connection requests and processes them.
 * Parameter: the proxy to run.
 * Return: none.
 */
void Proxy_run(Proxy proxy)
{
    // unsigned short listen_port = proxy->port;
    // printf("Port number for proxy is: %u\n", listen_port);
    Proxy_server(proxy);
}

/* Debug print, prints the contents of the proxy's cache */
void Proxy_print(Proxy proxy)
{
    Cache_print(proxy->cache);
}


/**
 * Proxy_server
 * Purpose: Has current proxy behave like a server, 
 *          listening for client requests.
 * Parameter: the proxy to run.
 * Return: none.
 */
void Proxy_server(Proxy proxy)
{
    int parentfd, childfd;
    int clientlen;
    struct sockaddr_in serveraddr, clientaddr;
    struct hostent *hostp;
    unsigned short portno = proxy->port;

    char *hostaddrp;
    int optval;

    /* 
     * make a socket 
     */
    parentfd = socket(PF_INET, SOCK_STREAM, 0);
    if (parentfd < 0) {
        fprintf(stderr, "socket error: could not create socket for (server)\n");
        exit(1);
    }

    optval = 1;
    setsockopt(parentfd, SOL_SOCKET, SO_REUSEADDR, 
               (const void *) &optval, sizeof(int));

    bzero((char *) &serveraddr, sizeof(serveraddr));
    serveraddr.sin_family = AF_INET;
    serveraddr.sin_addr.s_addr = htonl(INADDR_ANY);
    serveraddr.sin_port = htons(portno);

    /* 
     * bind parent socket to the port we passed in to getaddrinfo() 
     */
    int b = bind(parentfd, (struct sockaddr *) &serveraddr, sizeof(serveraddr));
    if (b < 0) {
        fprintf(stderr, "binding error: could not bind\n");
        exit(1);
    }

    /* listen for connection requests from client */
    int l = listen(parentfd, BACKLOG);
    if (l < 0) {
        fprintf(stderr, "listening error: cannot listen for connections\n");
        exit(1);
    }

    clientlen = sizeof(clientaddr);

    Cache cache = proxy->cache;
    CacheLine line;

    /* 
     * continuously listen for connection requests 
     */
    // int a = 0;
    // while (a != 3) {
    while (1) {
        /* 
         * accept: wait for connection request 
         */
        childfd = accept(parentfd, (struct sockaddr *) &clientaddr, &clientlen);
        if (childfd < 0) {
            fprintf(stderr, "accepting error\n");
            exit(1);
        }

        /* 
         * gethostbyaddr: determine who sent the message 
         */
        hostp = gethostbyaddr((const char *) &clientaddr.sin_addr.s_addr,
                              sizeof(clientaddr.sin_addr.s_addr), AF_INET);
        if (hostp == NULL) {
            fprintf(stderr, "gethostbyaddr error\n");
            exit(1);
        }

        hostaddrp = inet_ntoa(clientaddr.sin_addr);
        if (hostaddrp == NULL) {
            fprintf(stderr, "inet_ntoa error\n");
            exit(1);
        }


        /* 
         * read the message (GET request) from client (input string) 
         */ 
        int requestSize = 0;
        char *requestBuf = NULL;
        Proxy_read(childfd, &requestBuf, &requestSize);
        // parse_printBufVertical(requestBuf, requestSize);

        /* 
         * Check if requested item is in the cache by using the 
         * host name in the header. 
         */
        /* Parse request header */
        char *header = parse_headerLower(requestBuf);
        /* parse out Host, hostname, and port number */
        char *hostname;  /* malloc'd */
        char *resource; /* malloc'd */
        unsigned short destinationport = 80;
        parse_host(header, &resource, &hostname, &destinationport);
        fprintf(stderr, "Resource: %s (%s\t%d)\n\n", resource, hostname, destinationport);

        free(header);

        /* use hostname:port (host) as the key to find it in the cache. */
        line = Cache_get(cache, resource);

        if (line == NULL || CacheLine_isStale(line)) {
            /***************************************************************
             * Make a request to server if not in cache 
             ***/
            /* send/forward request to host and get response */
            unsigned long respSize = 0;
            char *response = Proxy_client(proxy, requestBuf, requestSize, 
                                          hostname, destinationport, &respSize);
            if (response == NULL) {
                fprintf(stderr, "error fetching from servers\n");
            } else {
                
                /* get the max-age from the response header */
                char *respHeader = parse_headerLower(response); /* malloc'd */
                unsigned int age = parse_maxAge(respHeader);
                free(respHeader);

                /* put the response in the cache 
                Note: DO NOT dealocate resource or response. These malloc'd 
                memories are stored in the cache. Size problems arise in 
                program when I constantly free these, even when the cache 
                malloc's its own copies. */
                // Cache_put(cache, host, response, respSize, age);
                Cache_put(cache, resource, response, respSize, age);

                /* write: Forward the response back to the client */
                int writeSize = write(childfd, response, respSize);
                if (writeSize < 0) {
                    fprintf(stderr, "error writing to socket: %s\n", strerror(writeSize));
                    exit(1);
                }
            }
            /* close the connection with client */
            close(childfd);
            free(requestBuf);
            free(hostname);
            /**************************************************************/
        } else {
            /* ***********************************************************
             * Retrieve response from Cache. Should append Age (in cache)
             ***/
            free(resource);
            
            unsigned long respSize = CacheLine_memorySize(line);
            /* this is the pointer to cache-stored Response's RAW data. 
               DO NOT free it after writing to client. */
            char *response = CacheLine_memory(line); 
    
            /****
             * Modify response ot include Age in header. 
             **/
            /* 1) Get current age and make it a header field. */
            unsigned int currentage = CacheLine_reportCurrentAge(line);
            char *ageField = make_ageField(currentage); /* malloc'd */
            unsigned long ageFieldSize = strlen(ageField);

            /* 2) separate header and body */
            char *respHeader = parse_headerRawTrim(response); /* malloc'd */
            char *respBody = parse_bodyRaw(response, respSize); /* malloc'd */
            unsigned long respHeaderSize = strlen(respHeader);
            unsigned long respBodySize = calculate_bodySize(response, respSize);

            /* 3) append the age field to response header */
            char ends[] = "\r\n"; 
            unsigned long newRespHdrSize = respHeaderSize + ageFieldSize + 2;
            char *newResponseHeader = calloc(newRespHdrSize + 1, 
                                             sizeof(char)); /* calloc'd */
            if (newResponseHeader == NULL) {
                fprintf(stderr, "error calloc'ing memory\n");
                exit(1);
            }
            memcpy(newResponseHeader, respHeader, respHeaderSize);
            memcpy(newResponseHeader + respHeaderSize, ageField, ageFieldSize);
            memcpy(newResponseHeader + respHeaderSize + ageFieldSize, ends, 2);
            // printf("Augmented Header1:\n");
            // parse_printcharsvertical(newResponseHeader, newRespHdrSize);
            // printf("%s\n\n", newResponseHeader);

            /* 4) stitch together new response with augmented head 
                  and old body */
            unsigned long newRespSize = respSize + ageFieldSize; /* calloc'd */
            char *newResponse = calloc(newRespSize + 1, sizeof(char)); 
            if (newResponse == NULL) {
                fprintf(stderr, "error calloc'ing memory\n");
                exit(1);
            }
            memcpy(newResponse, newResponseHeader, newRespHdrSize);
            memcpy(newResponse + newRespHdrSize, respBody, respBodySize);
            // parse_printcharsvertical(newResponse, newRespSize);

            /* write: Forward the response back to the client */
            int writeSize = write(childfd, newResponse, newRespSize);
            // printf("write (0)\n\n");
            if (writeSize < 0) {
                fprintf(stderr, "error writing to socket: %s\n", strerror(writeSize));
                exit(1);
            }
            /* close the connection with client */
            close(childfd);
            free(newResponse);
            free(newResponseHeader);
            free(ageField);
            free(respHeader);
            free(respBody);
            free(hostname);
            free(requestBuf);
            /**************************************************************/
        }
        // a++;
        // Proxy_print(proxy);
    } // End while loop
}


/**
 * Proxy_client
 * Purpose: Has current proxy behave like a client, 
 *          making requests to servers.
 * Parameter: the proxy to run.
 * Return: none.
 */
char *Proxy_client(Proxy proxy, char *request, size_t requestSize,
                          char *hostname, unsigned short port,
                          unsigned long *size)
{
    (void) proxy;
    /* 
     * make socket 
     */
    struct sockaddr_in saddr;
    struct hostent *h;
    int sockfd, connfd;

    sockfd = socket(PF_INET, SOCK_STREAM, 0);
    if (sockfd < 0) {
        fprintf(stderr, "socket error: could not create socket for (client)\n");
        exit(1);
    }

    h = gethostbyname(hostname);
    if (h == NULL) {
        fprintf(stderr, "unknown host\n");
        return NULL;
    }

    memset(&saddr, '\0', sizeof(saddr));
    saddr.sin_family = AF_INET;
    memcpy((char *) &saddr.sin_addr.s_addr, h->h_addr_list[0], h->h_length);
    saddr.sin_port = htons(port);


    /* 
     * make connection request 
     */
    connfd = connect(sockfd, (struct sockaddr *) &saddr, sizeof(saddr));
    if (connfd < 0) {
        fprintf(stderr, "cannot connect to host's server");
        return NULL;
    }

    /* 
     * send (write) message to server 
     */
    long msgsize = write(sockfd, request, requestSize); 
    if (msgsize < 0) {
        fprintf(stderr, "error writing to socket\n");
        return NULL;
    }

    /* 
     * receive message from server 
     */
    int responseSize = 0;
    char *responseBuf = NULL; /* malloc'd */
    Proxy_read(sockfd, &responseBuf, &responseSize);

    /* close the socket */
    close(sockfd);

    *size = responseSize;
    return responseBuf;
}



/**
 * Proxy_readRequest
 * Purpose: reads from the given file descripter until 
 *          the number of bytes that was meant to be sent 
 *          is received. buffer stores what was read, and 
 *          the number of bytes received is in bytesRead.
 */
void Proxy_read(int fd, char **buffer, int *bytesRead)
{
    *buffer = calloc(BUFSIZE + 1, sizeof(char));
    if (*buffer == NULL) {
        fprintf(stderr, "cannot calloc buffer memory.\n");
        exit(1);
    }
    *bytesRead = 0;
    int n = 0, capacity = BUFSIZE + 1, bytes = BUFSIZE;

    /* Look for complete header */
    /*****************************************************************/
    while (!hasHeader(*buffer)) {
        // fprintf(stderr, "BUFFER (0):\n%s\n\n", *buffer);
        *buffer = realloc(*buffer, capacity);
        n = read(fd, *buffer + *bytesRead, bytes);
        if (n < 0) {
            fprintf(stderr, "error reading from socket.\n");
            exit(1);
        }
        *bytesRead += n;
        (*buffer)[*bytesRead] = '\0'; /* place a \0 at end in order to parse */
        capacity += BUFSIZE;
        // fprintf(stderr, "BUFFER (1):\n%s\n\n", *buffer);
    }

    /* buffer currently contains a header; copy header, it ends in HRDFLAG */
    char *header = parse_headerLower(*buffer); /* malloc'd */
    /*****************************************************************/

    /* Parse out Content-length */
    /*****************************************************************/
    long contentLength = parse_contentLength(header);
    // fprintf(stderr, "Content-Length: %d\n\n", contentLength);
    if (contentLength < 0) {
        /* No Content-Length field; read only header */
        free(header);
        // fprintf(stderr, "BUFFER (2):\n%s\n\n", *buffer);
        *buffer = realloc(*buffer, *bytesRead); /* remv hardcoded \0 at end */
        return;
    }
    /******************************************************************/
    

    /* read in bytes until you've read body size */
    /*****************************************************************/
    unsigned long header_size = strlen(header);
    unsigned long bytes_of_body_read = (unsigned long) *bytesRead - header_size;
    unsigned long bytes_left_to_read = contentLength - bytes_of_body_read;
    free(header);

    // fprintf(stderr, "header_size: %u\n\n", header_size);
    // fprintf(stderr, "bytes_of_body_read: %u\n\n", bytes_of_body_read);
    // fprintf(stderr, "bytes_left_to_read: %u\n\n", bytes_left_to_read);

    while (bytes_left_to_read != 0) {
        *buffer = realloc(*buffer, capacity);
        n = read(fd, *buffer + *bytesRead, bytes);
        if (n < 0) {
            fprintf(stderr, "error reading from socket.\n");
            exit(1);
        }
        *bytesRead += n;
        bytes_left_to_read = bytes_left_to_read - (unsigned long) n;
        (*buffer)[*bytesRead] = '\0'; /* place a \0 at end in order to parse */
        capacity += BUFSIZE;
    }
    // fprintf(stderr, "BUFFER (3):\n%s\n\n", *buffer);

    *buffer = realloc(*buffer, *bytesRead); /* this trims off the \0 of buf */
    /*****************************************************************/
}